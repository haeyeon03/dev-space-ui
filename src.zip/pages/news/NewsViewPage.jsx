const NewsViewPage = () => {
  return <div>NewsViewPage</div>;
};

export default NewsViewPage;

const AdminUserListPage = () => {
  return <div>AdminUserListPage</div>;
};

export default AdminUserListPage;

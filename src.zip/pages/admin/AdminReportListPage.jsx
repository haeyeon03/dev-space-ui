const AdminReportListPage = () => {
  return <div>AdminReportListPage</div>;
};

export default AdminReportListPage;

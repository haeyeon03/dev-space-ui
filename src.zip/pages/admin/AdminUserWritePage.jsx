const AdminUserWritePage = () => {
  return <div>AdminUserWritePage</div>;
};

export default AdminUserWritePage;

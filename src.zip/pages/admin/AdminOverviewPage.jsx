const AdminOverviewPage = () => {
  return <div>AdminOverviewPage</div>;
};

export default AdminOverviewPage;

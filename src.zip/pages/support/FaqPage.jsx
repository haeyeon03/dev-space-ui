const FaqPage = () => {
  return <div>FaqPage</div>;
};

export default FaqPage;

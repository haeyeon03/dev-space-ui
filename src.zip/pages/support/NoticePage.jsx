const NoticePage = () => {
  return <div>NoticePage</div>;
};

export default NoticePage;

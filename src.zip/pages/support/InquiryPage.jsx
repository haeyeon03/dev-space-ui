const InquiryPage = () => {
  return <div>InquiryPage</div>;
};

export default InquiryPage;

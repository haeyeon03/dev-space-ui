const SignInPage = () => {
  return <div>SignInPage</div>;
};

export default SignInPage;

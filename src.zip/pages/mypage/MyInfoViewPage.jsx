const MyInfoViewPage = () => {
  return <div>MyInfoViewPage </div>;
};

export default MyInfoViewPage;

const MyInfoWritePage = () => {
  return <div>MyInfoWritePage </div>;
};

export default MyInfoWritePage;

const BoardWritePage = () => {
  return <div>BoardWritePage</div>;
};

export default BoardWritePage;

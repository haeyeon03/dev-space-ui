const BoardViewPage = () => {
  return <div>BoardViewPage</div>;
};

export default BoardViewPage;

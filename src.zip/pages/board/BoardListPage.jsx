const BoardListPage = () => {
  return <div>BoardListPage</div>;
};

export default BoardListPage;

const LoadingPage = () => {
  return <div>Now Loading...</div>;
};

export default LoadingPage;
